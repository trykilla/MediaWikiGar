-- Drop unused index echo_notification_user_hash_timestamp
DROP INDEX /*i*/echo_notification_user_hash_timestamp ON /*_*/echo_notification;
