-- Rename index to match table prefix - T306473
DROP INDEX /*i*/echo_push_subscription_token ON /*_*/echo_push_subscription;
