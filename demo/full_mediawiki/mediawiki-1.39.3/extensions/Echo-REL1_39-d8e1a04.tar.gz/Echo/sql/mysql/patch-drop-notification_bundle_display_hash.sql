-- Drop unused field notification_bundle_display_hash
ALTER TABLE /*_*/echo_notification DROP notification_bundle_display_hash;
